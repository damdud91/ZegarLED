#ifndef ADC_H_
#define ADC_H_

#include <avr/io.h>

#include "Zegarek.h"

void InitADC(void);

#endif /* ADC_H_ */